# coding=utf-8
"""Xingli Assistant update subsystem.

Design goals for MO2 2.4.4 / Python 3.8:
- one update implementation only;
- Gitee -> GitCode -> GitHub mirror failover;
- no third-party Python dependency;
- HTTPS certificate verification stays enabled;
- mandatory SHA-256 and ZIP integrity verification;
- never overwrite a loaded plugin in-process;
- stage first, apply after MO2 exits, atomic directory swap + rollback.
"""

import configparser
import hashlib
import json
import os
import re
import shutil
import tempfile
import urllib.error
import urllib.request
import webbrowser
import zipfile
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple

try:
    import PyQt6.QtWidgets as QtWidgets
    import PyQt6.QtGui as QtGui
    from PyQt6.QtCore import Qt, QThread, pyqtSignal
except ImportError:
    import PyQt5.QtWidgets as QtWidgets
    import PyQt5.QtGui as QtGui
    from PyQt5.QtCore import Qt, QThread, pyqtSignal

from . import stability

logger = stability.get_logger("updater")

SECTION = "AutoUpdate"
PRODUCT_ID = "xingli_Little_assistant"
SOURCES_FILE = "update_sources.json"
DEFAULT_CHECK_INTERVAL_HOURS = 24
DEFAULT_TIMEOUT_SECONDS = 8
USER_AGENT = "Xingli-MO2-Assistant-Updater/1.9.2"
PLACEHOLDER_MARKERS = ("YOUR_", "<owner>", "<repo>", "example.com")


def _exec_dialog(dialog):
    if hasattr(dialog, "exec"):
        return dialog.exec()
    return dialog.exec_()


def _align_center():
    if hasattr(Qt, "AlignmentFlag"):
        return Qt.AlignmentFlag.AlignCenter
    return Qt.AlignCenter


def _question(parent, title, text):
    buttons = (
        QtWidgets.QMessageBox.StandardButton.Yes | QtWidgets.QMessageBox.StandardButton.No
        if hasattr(QtWidgets.QMessageBox, "StandardButton")
        else QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No
    )
    yes = QtWidgets.QMessageBox.StandardButton.Yes if hasattr(QtWidgets.QMessageBox, "StandardButton") else QtWidgets.QMessageBox.Yes
    return QtWidgets.QMessageBox.question(parent, title, text, buttons) == yes


def normalize_version(version: str) -> Tuple[int, ...]:
    nums = re.findall(r"\d+", str(version or ""))
    return tuple(int(x) for x in nums[:6]) if nums else (0,)


def compare_versions(left: str, right: str) -> int:
    a = list(normalize_version(left))
    b = list(normalize_version(right))
    width = max(len(a), len(b))
    a += [0] * (width - len(a))
    b += [0] * (width - len(b))
    return (a > b) - (a < b)


def _plugin_path(controller) -> str:
    return os.path.abspath(getattr(controller, "plugin_path", os.path.dirname(__file__)))


def _base_path(controller) -> str:
    try:
        organizer = getattr(controller, "organizer", None)
        if organizer:
            value = organizer.basePath()
            if value:
                return os.path.abspath(str(value))
    except Exception:
        pass
    return os.path.abspath(os.path.join(_plugin_path(controller), "..", ".."))


def settings_path(controller) -> str:
    return getattr(controller, "settings_path", os.path.join(_plugin_path(controller), "settings.ini"))


def sources_path(controller) -> str:
    return os.path.join(_plugin_path(controller), SOURCES_FILE)


def updates_dir(controller) -> str:
    path = os.path.join(_base_path(controller), "_XingliUpdates")
    os.makedirs(path, exist_ok=True)
    return path


def _read_ini(path: str) -> configparser.ConfigParser:
    config = configparser.ConfigParser()
    if os.path.exists(path):
        try:
            config.read(path, encoding="utf-8")
        except Exception:
            config = configparser.ConfigParser()
    if SECTION not in config:
        config[SECTION] = {}
    return config


def _write_ini(path: str, config: configparser.ConfigParser) -> None:
    with open(path, "w", encoding="utf-8") as handle:
        config.write(handle)


def get_update_settings(controller) -> Dict[str, str]:
    config = _read_ini(settings_path(controller))
    section = config[SECTION]
    defaults = {
        "AutoCheckOnStartup": "true",
        "CheckIntervalHours": str(DEFAULT_CHECK_INTERVAL_HOURS),
        "LastCheck": "",
        "SkippedVersion": "",
    }
    for key, value in defaults.items():
        if not section.get(key):
            section[key] = value
    return {k: section.get(k, "") for k in section.keys()}


def set_update_settings(controller, auto_check: bool, interval_hours: int,
                        last_check: Optional[str] = None, skipped_version: Optional[str] = None) -> None:
    path = settings_path(controller)
    config = _read_ini(path)
    config[SECTION]["AutoCheckOnStartup"] = "true" if auto_check else "false"
    config[SECTION]["CheckIntervalHours"] = str(max(1, int(interval_hours or DEFAULT_CHECK_INTERVAL_HOURS)))
    if last_check is not None:
        config[SECTION]["LastCheck"] = last_check
    if skipped_version is not None:
        config[SECTION]["SkippedVersion"] = skipped_version
    _write_ini(path, config)


def _valid_remote_url(url: str) -> bool:
    value = str(url or "").strip()
    if not value:
        return False
    if any(marker.lower() in value.lower() for marker in PLACEHOLDER_MARKERS):
        return False
    return value.startswith("https://") or value.startswith("http://") or value.startswith("file://")


def load_update_sources(controller) -> Dict[str, object]:
    path = sources_path(controller)
    if not os.path.exists(path):
        return {"schema": 1, "timeout_seconds": DEFAULT_TIMEOUT_SECONDS, "manifest_urls": []}
    try:
        with open(path, "r", encoding="utf-8-sig") as handle:
            data = json.load(handle)
        urls = [str(x).strip() for x in data.get("manifest_urls", []) if _valid_remote_url(str(x))]
        timeout = int(data.get("timeout_seconds", DEFAULT_TIMEOUT_SECONDS) or DEFAULT_TIMEOUT_SECONDS)
        return {
            "schema": int(data.get("schema", 1) or 1),
            "timeout_seconds": max(3, min(30, timeout)),
            "manifest_urls": urls,
        }
    except Exception as exc:
        logger.exception("读取更新源失败")
        raise RuntimeError("更新源配置损坏：{}".format(exc))


def _request_bytes(url: str, timeout: int) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/json,*/*"})
    with urllib.request.urlopen(req, timeout=timeout) as response:
        return response.read()


def _source_name(url: str) -> str:
    low = url.lower()
    if "gitee.com" in low:
        return "Gitee 国内主源"
    if "gitcode.com" in low:
        return "GitCode 国内备用源"
    if "github.com" in low or "githubusercontent.com" in low:
        return "GitHub 备用源"
    if low.startswith("file://"):
        return "本地测试源"
    return "备用更新源"


def validate_manifest(data: Dict[str, object]) -> Dict[str, object]:
    if not isinstance(data, dict):
        raise RuntimeError("更新清单不是 JSON 对象。")
    schema = int(data.get("schema", 0) or 0)
    if schema < 2:
        raise RuntimeError("更新清单版本过旧，需要 schema 2 或更高。")
    if str(data.get("product", "")) != PRODUCT_ID:
        raise RuntimeError("更新清单不属于星黎助手。")
    version = str(data.get("version", "")).strip()
    if not version or normalize_version(version) == (0,):
        raise RuntimeError("更新清单缺少有效版本号。")
    package = data.get("package")
    if not isinstance(package, dict):
        raise RuntimeError("更新清单缺少 package。")
    sha256 = str(package.get("sha256", "")).strip().lower()
    if not re.fullmatch(r"[0-9a-f]{64}", sha256):
        raise RuntimeError("更新包必须提供有效 SHA256。")
    mirrors = package.get("mirrors")
    if not isinstance(mirrors, list) or not mirrors:
        raise RuntimeError("更新清单没有可用下载源。")
    usable = []
    for item in mirrors:
        if isinstance(item, str):
            url = item
            name = _source_name(url)
        elif isinstance(item, dict):
            url = str(item.get("url", ""))
            name = str(item.get("name", "") or _source_name(url))
        else:
            continue
        if _valid_remote_url(url):
            usable.append({"name": name, "url": url})
    if not usable:
        raise RuntimeError("更新清单中的下载源都不可用。")
    package = dict(package)
    package["sha256"] = sha256
    package["mirrors"] = usable
    result = dict(data)
    result["package"] = package
    return result


def fetch_manifest_from_mirrors(urls: List[str], timeout: int) -> Tuple[Dict[str, object], str]:
    if not urls:
        raise RuntimeError("作者尚未配置更新源。")
    errors = []
    for url in urls:
        try:
            raw = _request_bytes(url, timeout).decode("utf-8-sig")
            data = validate_manifest(json.loads(raw))
            return data, url
        except Exception as exc:
            errors.append("{}: {}".format(_source_name(url), exc))
            logger.warning("更新清单源失败 %s: %s", url, exc)
    raise RuntimeError("所有更新源均不可用。\n" + "\n".join(errors[-3:]))


class ManifestCheckThread(QThread):
    checked = pyqtSignal(dict, str)
    failed = pyqtSignal(str)

    def __init__(self, urls: List[str], timeout: int):
        super().__init__()
        self.urls = list(urls)
        self.timeout = int(timeout)

    def run(self):
        try:
            manifest, source = fetch_manifest_from_mirrors(self.urls, self.timeout)
            self.checked.emit(manifest, source)
        except Exception as exc:
            self.failed.emit(str(exc))


class MirrorDownloadThread(QThread):
    progress = pyqtSignal(int, str)
    finished = pyqtSignal(str, str)
    failed = pyqtSignal(str)

    def __init__(self, mirrors: List[Dict[str, str]], target_path: str, expected_sha256: str,
                 expected_size: int = 0, timeout: int = 15):
        super().__init__()
        self.mirrors = list(mirrors)
        self.target_path = target_path
        self.expected_sha256 = expected_sha256.lower()
        self.expected_size = int(expected_size or 0)
        self.timeout = int(timeout)

    def run(self):
        errors = []
        for mirror in self.mirrors:
            name = str(mirror.get("name", "更新源"))
            url = str(mirror.get("url", ""))
            temp_path = None
            try:
                self.progress.emit(0, "正在连接 {}…".format(name))
                req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/zip,*/*"})
                with urllib.request.urlopen(req, timeout=self.timeout) as response:
                    total = int(response.headers.get("Content-Length", 0) or 0)
                    fd, temp_path = tempfile.mkstemp(prefix="xingli_update_", suffix=".download")
                    os.close(fd)
                    sha = hashlib.sha256()
                    done = 0
                    with open(temp_path, "wb") as handle:
                        while True:
                            chunk = response.read(256 * 1024)
                            if not chunk:
                                break
                            handle.write(chunk)
                            sha.update(chunk)
                            done += len(chunk)
                            if total > 0:
                                self.progress.emit(max(0, min(99, int(done * 100 / total))), "正在从 {} 下载…".format(name))
                if self.expected_size and done != self.expected_size:
                    raise RuntimeError("文件大小不一致（{} / {} 字节）".format(done, self.expected_size))
                digest = sha.hexdigest().lower()
                if digest != self.expected_sha256:
                    raise RuntimeError("SHA256 校验失败")
                if not zipfile.is_zipfile(temp_path):
                    raise RuntimeError("下载内容不是有效 ZIP")
                with zipfile.ZipFile(temp_path, "r") as archive:
                    bad = archive.testzip()
                    if bad:
                        raise RuntimeError("ZIP 校验失败：{}".format(bad))
                os.makedirs(os.path.dirname(self.target_path), exist_ok=True)
                if os.path.exists(self.target_path):
                    os.remove(self.target_path)
                shutil.move(temp_path, self.target_path)
                temp_path = None
                self.progress.emit(100, "下载完成")
                self.finished.emit(self.target_path, name)
                return
            except Exception as exc:
                errors.append("{}: {}".format(name, exc))
                logger.warning("更新下载源失败 %s %s: %s", name, url, exc)
                if temp_path and os.path.exists(temp_path):
                    try:
                        os.remove(temp_path)
                    except Exception:
                        pass
        self.failed.emit("所有下载源均失败。\n" + "\n".join(errors[-3:]))


def _safe_extract_zip(archive: zipfile.ZipFile, target_dir: str) -> None:
    root = os.path.abspath(target_dir)
    prefix = root + os.sep
    for member in archive.infolist():
        path = os.path.abspath(os.path.join(root, member.filename))
        if path != root and not path.startswith(prefix):
            raise RuntimeError("更新包包含异常路径：{}".format(member.filename))
    archive.extractall(root)


def _find_plugin_source(stage: str) -> str:
    direct = os.path.join(stage, PRODUCT_ID)
    if os.path.isfile(os.path.join(direct, "__init__.py")):
        return direct
    if os.path.isfile(os.path.join(stage, "__init__.py")):
        return stage
    for root, dirs, files in os.walk(stage):
        if os.path.basename(root) == PRODUCT_ID and "__init__.py" in files:
            return root
    raise RuntimeError("更新包里没有找到星黎助手插件目录。")


def _read_staged_version(source_dir: str) -> str:
    path = os.path.join(source_dir, "version.ini")
    config = configparser.ConfigParser()
    if not os.path.exists(path):
        raise RuntimeError("更新包缺少 version.ini。")
    config.read(path, encoding="utf-8")
    value = config.get("Version", "local", fallback="").strip()
    if not value:
        raise RuntimeError("更新包版本信息无效。")
    return value


def _ps_quote(value: str) -> str:
    return "'" + str(value).replace("'", "''") + "'"


def prepare_staged_update(controller, package_path: str, manifest: Dict[str, object]) -> Dict[str, str]:
    root = updates_dir(controller)
    version = re.sub(r"[^0-9A-Za-z_.-]+", "_", str(manifest.get("version", "update")))
    stage = os.path.join(root, "staged", version)
    if os.path.isdir(stage):
        shutil.rmtree(stage, ignore_errors=True)
    os.makedirs(stage, exist_ok=True)
    with zipfile.ZipFile(package_path, "r") as archive:
        _safe_extract_zip(archive, stage)
    source = _find_plugin_source(stage)
    staged_version = _read_staged_version(source)
    expected_version = str(manifest.get("version", ""))
    if compare_versions(staged_version, expected_version) != 0:
        raise RuntimeError("更新包版本 {} 与清单版本 {} 不一致。".format(staged_version, expected_version))

    plugin_dir = _plugin_path(controller)
    mo2_dir = _base_path(controller)
    mo2_exe = os.path.join(mo2_dir, "ModOrganizer.exe")
    pending = {
        "schema": 1,
        "product": PRODUCT_ID,
        "version": expected_version,
        "prepared_at": datetime.now().isoformat(timespec="seconds"),
        "source_dir": source,
        "plugin_dir": plugin_dir,
        "package": package_path,
    }
    pending_path = os.path.join(root, "pending_update.json")
    with open(pending_path, "w", encoding="utf-8") as handle:
        json.dump(pending, handle, ensure_ascii=False, indent=2)

    ps1_path = os.path.join(root, "Install_Xingli_Update_{}.ps1".format(version))
    bat_path = os.path.join(root, "安装星黎更新_{}.bat".format(version))
    result_path = os.path.join(root, "last_update_result.json")
    backups = os.path.join(root, "backups")

    ps1 = r'''$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$PluginDir = {plugin_dir}
$SourceDir = {source_dir}
$Mo2Exe = {mo2_exe}
$BackupRoot = {backup_root}
$ResultPath = {result_path}
$Version = {version}

Write-Host '========================================'
Write-Host '        星黎助手安全更新'
Write-Host '========================================'
Write-Host '更新已准备完成。请正常关闭 Mod Organizer 2。'
Write-Host '安装器会等待 MO2 完全退出，不会强制结束进程。'
Write-Host ''

while (Get-Process -Name 'ModOrganizer' -ErrorAction SilentlyContinue) {{ Start-Sleep -Seconds 1 }}
Start-Sleep -Milliseconds 800

$PluginsParent = Split-Path -Parent $PluginDir
$Stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$BackupDir = Join-Path $BackupRoot ('xingli_Little_assistant_' + $Stamp)
$NewDir = Join-Path $PluginsParent 'xingli_Little_assistant.__new__'
$OldDir = Join-Path $PluginsParent 'xingli_Little_assistant.__old__'

function Write-Result([string]$status, [string]$message, [string]$backup) {{
    $obj = [ordered]@{{ schema = 1; status = $status; version = $Version; message = $message; backup = $backup; time = (Get-Date).ToString('s') }}
    $obj | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $ResultPath -Encoding UTF8
}}

try {{
    New-Item -ItemType Directory -Path $BackupRoot -Force | Out-Null
    if (Test-Path -LiteralPath $NewDir) {{ Remove-Item -LiteralPath $NewDir -Recurse -Force }}
    if (Test-Path -LiteralPath $OldDir) {{ Remove-Item -LiteralPath $OldDir -Recurse -Force }}
    Copy-Item -LiteralPath $SourceDir -Destination $NewDir -Recurse -Force
    if (!(Test-Path -LiteralPath (Join-Path $NewDir '__init__.py'))) {{ throw '新版本缺少 __init__.py' }}
    if (!(Test-Path -LiteralPath (Join-Path $NewDir 'version.ini'))) {{ throw '新版本缺少 version.ini' }}

    if (Test-Path -LiteralPath $PluginDir) {{
        Copy-Item -LiteralPath $PluginDir -Destination $BackupDir -Recurse -Force
        Move-Item -LiteralPath $PluginDir -Destination $OldDir
    }}
    Move-Item -LiteralPath $NewDir -Destination $PluginDir
    if (Test-Path -LiteralPath $OldDir) {{ Remove-Item -LiteralPath $OldDir -Recurse -Force }}
    Write-Result 'success' '更新安装成功' $BackupDir
    Write-Host '[完成] 更新安装成功。'
}} catch {{
    $msg = $_.Exception.Message
    Write-Host ('[失败] ' + $msg)
    try {{
        if (Test-Path -LiteralPath $PluginDir) {{ Remove-Item -LiteralPath $PluginDir -Recurse -Force }}
        if (Test-Path -LiteralPath $OldDir) {{ Move-Item -LiteralPath $OldDir -Destination $PluginDir }}
        elseif (Test-Path -LiteralPath $BackupDir) {{ Copy-Item -LiteralPath $BackupDir -Destination $PluginDir -Recurse -Force }}
        Write-Result 'rolled_back' ('更新失败，已恢复旧版本：' + $msg) $BackupDir
        Write-Host '[已恢复] 已恢复更新前版本。'
    }} catch {{
        Write-Result 'rollback_failed' ('更新失败且自动恢复失败：' + $msg) $BackupDir
        Write-Host '[严重] 自动恢复失败，请保留此窗口并查看 backups 目录。'
    }}
}}

if (Test-Path -LiteralPath $Mo2Exe) {{ Start-Process -FilePath $Mo2Exe }}
Start-Sleep -Seconds 2
'''.format(
        plugin_dir=_ps_quote(plugin_dir), source_dir=_ps_quote(source), mo2_exe=_ps_quote(mo2_exe),
        backup_root=_ps_quote(backups), result_path=_ps_quote(result_path), version=_ps_quote(expected_version)
    )
    bat = '@echo off\r\nchcp 65001 >nul\r\ntitle 星黎助手安全更新\r\npowershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0{}"\r\n'.format(os.path.basename(ps1_path))
    with open(ps1_path, "w", encoding="utf-8-sig", newline="\r\n") as handle:
        handle.write(ps1)
    with open(bat_path, "w", encoding="utf-8-sig", newline="\r\n") as handle:
        handle.write(bat)
    return {"stage": stage, "source": source, "pending": pending_path, "installer": bat_path}


def read_last_update_result(controller) -> Optional[Dict[str, object]]:
    path = os.path.join(updates_dir(controller), "last_update_result.json")
    if not os.path.exists(path):
        return None
    try:
        with open(path, "r", encoding="utf-8-sig") as handle:
            return json.load(handle)
    except Exception:
        return None


class AutoUpdateDialog(QtWidgets.QDialog):
    def __init__(self, controller, parent=None):
        super().__init__(parent)
        self.controller = controller
        self.local_version = str(getattr(controller, "local_version", "") or "0.0.0")
        self.manifest = None
        self.manifest_source = ""
        self.prepared = None
        self.check_thread = None
        self.download_thread = None
        self.progress = None
        self.setWindowTitle("星黎助手更新")
        self.resize(760, 560)
        self._build_ui()
        self._load_settings()

    def _build_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        title = QtWidgets.QLabel("星黎助手更新")
        font = QtGui.QFont()
        font.setPointSize(15)
        font.setBold(True)
        title.setFont(font)
        title.setAlignment(_align_center())
        layout.addWidget(title)

        notice = QtWidgets.QLabel(
            "更新优先使用国内镜像；下载后会先校验并准备文件。\n"
            "安装时不会强制关闭 MO2，正常关闭 MO2 后会自动更新并重新打开。"
        )
        notice.setWordWrap(True)
        notice.setAlignment(_align_center())
        layout.addWidget(notice)

        form = QtWidgets.QFormLayout()
        self.local_label = QtWidgets.QLabel(self.local_version)
        form.addRow("当前版本：", self.local_label)
        self.source_label = QtWidgets.QLabel("尚未检查")
        form.addRow("更新源：", self.source_label)
        self.auto_check = QtWidgets.QCheckBox("打开 MO2 时自动检查")
        form.addRow("自动检查：", self.auto_check)
        self.interval_spin = QtWidgets.QSpinBox()
        self.interval_spin.setRange(1, 168)
        self.interval_spin.setSuffix(" 小时")
        form.addRow("检查间隔：", self.interval_spin)
        layout.addLayout(form)

        buttons = QtWidgets.QHBoxLayout()
        self.check_button = QtWidgets.QPushButton("检查更新")
        self.download_button = QtWidgets.QPushButton("下载并准备")
        self.install_button = QtWidgets.QPushButton("安装并重启")
        self.download_button.setEnabled(False)
        self.install_button.setEnabled(False)
        self.check_button.clicked.connect(self.check_updates)
        self.download_button.clicked.connect(self.download_update)
        self.install_button.clicked.connect(self.install_prepared_update)
        buttons.addWidget(self.check_button)
        buttons.addWidget(self.download_button)
        buttons.addWidget(self.install_button)
        layout.addLayout(buttons)

        self.info_text = QtWidgets.QPlainTextEdit()
        self.info_text.setReadOnly(True)
        layout.addWidget(self.info_text, 1)

        foot = QtWidgets.QHBoxLayout()
        open_btn = QtWidgets.QPushButton("打开更新目录")
        open_btn.clicked.connect(self.open_updates_dir)
        save_btn = QtWidgets.QPushButton("保存设置")
        save_btn.clicked.connect(self.save_settings)
        close_btn = QtWidgets.QPushButton("关闭")
        close_btn.clicked.connect(self.close)
        foot.addWidget(open_btn)
        foot.addStretch(1)
        foot.addWidget(save_btn)
        foot.addWidget(close_btn)
        layout.addLayout(foot)

    def _load_settings(self):
        settings = get_update_settings(self.controller)
        auto = (settings.get("autocheckonstartup") or "true").lower() in ("1", "yes", "true", "on")
        self.auto_check.setChecked(auto)
        try:
            interval = int(settings.get("checkintervalhours") or DEFAULT_CHECK_INTERVAL_HOURS)
        except Exception:
            interval = DEFAULT_CHECK_INTERVAL_HOURS
        self.interval_spin.setValue(max(1, min(168, interval)))
        result = read_last_update_result(self.controller)
        if result:
            self.info_text.setPlainText("上次更新：{}\n{}".format(result.get("status", ""), result.get("message", "")))

    def save_settings(self):
        set_update_settings(self.controller, self.auto_check.isChecked(), self.interval_spin.value())
        QtWidgets.QMessageBox.information(self, "已保存", "更新设置已保存。")

    def check_updates(self):
        self.save_settings()
        try:
            sources = load_update_sources(self.controller)
            urls = list(sources.get("manifest_urls", []))
            timeout = int(sources.get("timeout_seconds", DEFAULT_TIMEOUT_SECONDS))
        except Exception as exc:
            self._on_check_failed(str(exc))
            return
        if not urls:
            self._on_check_failed("作者尚未配置可用更新源。请先按照 UPDATE_PUBLISH_GUIDE_CN.md 配置国内镜像。")
            return
        self.info_text.setPlainText("正在检查更新……")
        self.check_button.setEnabled(False)
        self.check_thread = ManifestCheckThread(urls, timeout)
        self.check_thread.checked.connect(self._on_manifest_checked)
        self.check_thread.failed.connect(self._on_check_failed)
        self.check_thread.finished.connect(lambda: self.check_button.setEnabled(True))
        self.check_thread.start()

    def _on_manifest_checked(self, manifest, source):
        self.manifest = manifest
        self.manifest_source = source
        latest = str(manifest.get("version", "0.0.0"))
        newer = compare_versions(latest, self.local_version) > 0
        self.source_label.setText(_source_name(source))
        package = manifest.get("package", {})
        mirrors = package.get("mirrors", []) if isinstance(package, dict) else []
        text = [
            "状态：{}".format("发现新版本" if newer else "当前已经是最新版本"),
            "当前版本：{}".format(self.local_version),
            "最新版本：{}".format(latest),
            "检查来源：{}".format(_source_name(source)),
            "下载镜像：{} 个".format(len(mirrors)),
            "文件校验：SHA256 已启用",
            "",
            "更新说明：",
            str(manifest.get("changelog", "未提供更新说明。")),
        ]
        self.info_text.setPlainText("\n".join(text))
        set_update_settings(self.controller, self.auto_check.isChecked(), self.interval_spin.value(),
                            last_check=datetime.now().isoformat(timespec="seconds"))
        self.download_button.setEnabled(newer)

    def _on_check_failed(self, error):
        self.source_label.setText("检查失败")
        self.info_text.setPlainText("检查更新失败：\n{}".format(error))
        QtWidgets.QMessageBox.warning(self, "检查失败", str(error))

    def download_update(self):
        if not self.manifest:
            return
        package = self.manifest.get("package", {})
        if not isinstance(package, dict):
            return
        latest = str(self.manifest.get("version", "update"))
        safe_version = re.sub(r"[^0-9A-Za-z_.-]+", "_", latest)
        filename = str(package.get("filename", "xingli_update_{}.zip".format(safe_version)))
        if not filename.lower().endswith(".zip"):
            filename += ".zip"
        target = os.path.join(updates_dir(self.controller), filename)
        mirrors = list(package.get("mirrors", []))
        sha = str(package.get("sha256", ""))
        size = int(package.get("size", 0) or 0)
        self.progress = QtWidgets.QProgressDialog("正在下载更新……", "取消", 0, 100, self)
        self.progress.setWindowTitle("星黎助手更新")
        self.progress.setWindowModality(Qt.WindowModal)
        self.progress.setAutoClose(False)
        self.progress.setMinimumDuration(0)
        self.progress.show()
        self.download_thread = MirrorDownloadThread(mirrors, target, sha, size)
        self.download_thread.progress.connect(self._on_download_progress)
        self.download_thread.finished.connect(self._on_download_finished)
        self.download_thread.failed.connect(self._on_download_failed)
        self.download_thread.start()

    def _on_download_progress(self, value, text):
        if self.progress:
            self.progress.setValue(value)
            self.progress.setLabelText(text)

    def _on_download_finished(self, path, mirror_name):
        if self.progress:
            self.progress.close()
        try:
            self.prepared = prepare_staged_update(self.controller, path, self.manifest or {})
            self.install_button.setEnabled(True)
            self.info_text.appendPlainText("\n下载来源：{}\n更新已校验并准备完成。".format(mirror_name))
            QtWidgets.QMessageBox.information(self, "准备完成", "更新已下载并通过校验。\n点击【安装并重启】开始安全更新。")
        except Exception as exc:
            logger.exception("准备更新失败")
            QtWidgets.QMessageBox.critical(self, "准备失败", "更新文件已下载，但准备安装失败：\n{}".format(exc))

    def _on_download_failed(self, error):
        if self.progress:
            self.progress.close()
        QtWidgets.QMessageBox.critical(self, "下载失败", str(error))

    def install_prepared_update(self):
        if not self.prepared:
            return
        installer = self.prepared.get("installer", "")
        if not installer or not os.path.exists(installer):
            QtWidgets.QMessageBox.warning(self, "安装文件缺失", "请重新下载并准备更新。")
            return
        if not _question(self, "开始安装", "将启动安全更新助手。\n\n之后请正常关闭 MO2；更新助手会等待 MO2 完全退出，再替换插件并重新打开 MO2。\n\n现在继续吗？"):
            return
        try:
            os.startfile(installer)  # type: ignore[attr-defined]
            QtWidgets.QMessageBox.information(self, "更新助手已启动", "请正常关闭 MO2。\n不要强制结束 MO2；关闭后更新会自动继续。")
        except Exception as exc:
            QtWidgets.QMessageBox.critical(self, "启动失败", str(exc))

    def open_updates_dir(self):
        path = updates_dir(self.controller)
        try:
            if os.name == "nt":
                os.startfile(path)  # type: ignore[attr-defined]
            else:
                webbrowser.open("file://" + path)
        except Exception:
            webbrowser.open("file://" + path)


def show_auto_updater(controller, parent=None):
    if parent is None:
        try:
            parent = controller._parentWidget()
        except Exception:
            parent = getattr(controller, "window", None)
    dialog = AutoUpdateDialog(controller, parent)
    _exec_dialog(dialog)


def maybe_auto_check(controller, parent=None) -> None:
    """Silent startup check. Failures are logged only."""
    try:
        settings = get_update_settings(controller)
        auto = (settings.get("autocheckonstartup") or "true").lower() in ("1", "yes", "true", "on")
        if not auto:
            return
        try:
            interval = int(settings.get("checkintervalhours") or DEFAULT_CHECK_INTERVAL_HOURS)
        except Exception:
            interval = DEFAULT_CHECK_INTERVAL_HOURS
        last = settings.get("lastcheck") or ""
        if last:
            try:
                if datetime.now() - datetime.fromisoformat(last) < timedelta(hours=max(1, interval)):
                    return
            except Exception:
                pass
        sources = load_update_sources(controller)
        urls = list(sources.get("manifest_urls", []))
        if not urls:
            logger.info("自动更新未配置远程源，跳过启动检查")
            return
        thread = ManifestCheckThread(urls, int(sources.get("timeout_seconds", DEFAULT_TIMEOUT_SECONDS)))

        def on_checked(manifest, source):
            try:
                local = str(getattr(controller, "local_version", "") or "0.0.0")
                latest = str(manifest.get("version", "0.0.0"))
                set_update_settings(controller, True, interval, last_check=datetime.now().isoformat(timespec="seconds"))
                skipped = settings.get("skippedversion") or ""
                if compare_versions(latest, local) > 0 and compare_versions(latest, skipped) != 0:
                    if _question(parent, "发现星黎助手更新", "发现新版本：{}\n\n是否查看更新？".format(latest)):
                        dlg = AutoUpdateDialog(controller, parent)
                        dlg._on_manifest_checked(manifest, source)
                        _exec_dialog(dlg)
            except Exception:
                logger.exception("自动更新结果处理失败")

        def on_failed(error):
            logger.warning("自动更新检查失败: %s", error)
            try:
                set_update_settings(controller, True, interval, last_check=datetime.now().isoformat(timespec="seconds"))
            except Exception:
                pass

        controller._xingli_auto_update_thread = thread
        thread.checked.connect(on_checked)
        thread.failed.connect(on_failed)
        thread.start()
    except Exception:
        logger.exception("自动更新初始化失败")
