# 星黎 v2.4.2：无需 ZIP 的排序文本文件直传

- 原始 modlist.txt、plugins.txt、loadorder.txt、lockedorder.txt 可分别存入 GitHub/Gitee 仓库。
- 每个文件独立大小和 SHA256 校验，右侧三件套全部通过后才生成 MO2 可还原备份。
- 兼容旧 v2.4.1 的 ZIP 排序推送清单，不需要转换旧数据。
- 继续保留唯一日期序号命名和当前 Profile 的原有排序；不自动执行恢复。
- 暂时屏蔽单独 MOD 更新保持不变。
