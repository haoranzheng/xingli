# coding=utf-8
"""Build update/latest.json for Xingli Assistant releases (stdlib only)."""
import argparse, hashlib, json, os
from datetime import datetime, timezone


def sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('package')
    ap.add_argument('--version', required=True)
    ap.add_argument('--changelog', default='')
    ap.add_argument('--gitee', required=True, help='Gitee package URL')
    ap.add_argument('--gitcode', default='', help='GitCode package URL (optional)')
    ap.add_argument('--github', default='', help='GitHub package URL')
    ap.add_argument('--output', default='latest.json')
    a=ap.parse_args()
    mirrors=[{'name':'Gitee 国内主源','url':a.gitee}]
    if a.gitcode:
        mirrors.append({'name':'GitCode 国内备用源','url':a.gitcode})
    if a.github:
        mirrors.append({'name':'GitHub 备用源','url':a.github})
    data={
        'schema':2,'product':'xingli_Little_assistant','channel':'stable','version':a.version,
        'title':'星黎 MO2 小助手 '+a.version,
        'published_at':datetime.now(timezone.utc).astimezone().isoformat(timespec='seconds'),
        'changelog':a.changelog,
        'package':{
            'filename':os.path.basename(a.package),'size':os.path.getsize(a.package),
            'sha256':sha256(a.package),'mirrors':mirrors
        }
    }
    with open(a.output,'w',encoding='utf-8') as f: json.dump(data,f,ensure_ascii=False,indent=2)
    print(a.output)
    print(data['package']['sha256'])

if __name__=='__main__': main()
