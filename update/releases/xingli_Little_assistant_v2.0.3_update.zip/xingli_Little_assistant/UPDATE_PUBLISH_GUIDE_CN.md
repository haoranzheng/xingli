# 星黎助手国内自动更新发布方案

## 推荐结构

GitHub 作为主开发仓库；Gitee 为中国大陆主下载源；GitCode 为国内备用；GitHub 只做最后兜底。

远端仓库至少包含：

```text
update/
├─ latest.json
└─ releases/
   └─ xingli_Little_assistant_vX.Y.Z_update.zip
```

插件更新包很小，直接作为版本化文件放进公开代码仓即可。这样 GitHub→Gitee/GitCode 镜像同步的是普通 Git 文件，不依赖 Release 附件同步。

## 1. GitHub

现有主仓库可直接使用 `haoranzheng/xingli`，在其中保存源码和 `update/` 目录。

## 2. Gitee（国内主源）

从 GitHub 导入公开仓库，并配置 GitHub→Gitee 镜像；也可以每次发布后手动同步。

## 3. GitCode（国内备用）

建立同名公开仓库，将 `update/` 目录同步过去。也可以只在正式发布时推送。

## 4. 配置插件

编辑 `update_sources.json`，把三个 `YOUR_*` 替换成实际账号和仓库名。不要把私人 Token 放进插件。

## 5. 每次发布

1. 生成插件 ZIP。
2. 计算 ZIP 的 SHA256 和文件大小。
3. 把 ZIP 放入 `update/releases/`，文件名必须包含版本号，不覆盖旧版本。
4. 从 `update_manifest.example.json` 复制生成 `update/latest.json`。
5. 填写新版本、size、sha256 和三个镜像 URL。
6. 提交 GitHub，再同步 Gitee / GitCode。
7. 在正式推送给用户前，至少从中国大陆网络测试 Gitee 主源和 GitCode 备用源各一次。

## 为什么不用 Gitee Pages / 免费 CDN / GitHub 反代

更新器只需要静态 JSON 和 ZIP，不需要网站。Gitee Pages 对个人项目目前并不是可靠基础设施；免费 GitHub 反代域名也可能随时失效。公开代码仓 raw 文件更简单，且不需要额外服务器费用。

## 安全规则

- `latest.json` 必须使用 schema 2。
- ZIP 必须提供 SHA256；没有 SHA256 时客户端拒绝自动安装。
- ZIP 必须包含 `xingli_Little_assistant/__init__.py` 和 `version.ini`。
- 客户端不会在 MO2 运行中覆盖插件。
- 安装前自动备份当前插件目录。
- 使用目录级替换；失败自动恢复旧目录。
- 不关闭 HTTPS 证书验证。
- 不在客户端保存 Gitee/GitCode/GitHub Token。


## 当前正式更新源

- Gitee 国内主源：`https://gitee.com/HR-world/xingli`
- GitHub 备用源：`https://github.com/haoranzheng/xingli`

客户端版本清单读取顺序：

1. `https://gitee.com/HR-world/xingli/raw/main/update/latest.json`
2. `https://raw.githubusercontent.com/haoranzheng/xingli/main/update/latest.json`

当前尚未配置 GitCode。等 GitCode 镜像建立后，再把它插入 Gitee 与 GitHub 之间即可。
