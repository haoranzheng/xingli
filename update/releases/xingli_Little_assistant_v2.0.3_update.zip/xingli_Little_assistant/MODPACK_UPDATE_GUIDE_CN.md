# 星黎整合包更新提示

整合包内容更新与星黎助手自身更新是两套独立机制。

## 当前正式整合包

当前版本：`3.3.1`。

首次升级到星黎助手 v2.0.3 后，会把该版本写入 MO2 `pluginDataPath/xingli_assistant/modpack/installed_release.json`。
后续只更新“星黎助手”不会再改动这个整合包内容版本。

以后真实更新整合包内容时，更新包应在 MO2 根目录同时放置：

`xingli_modpack_release.json`

例如：

```json
{
  "schema": 2,
  "pack_id": "xingli-skyrim",
  "name": "星黎整合包",
  "installed_version": "3.4.0"
}
```

星黎助手读取到根目录版本后会同步到持久记录。

## 远程最新版本

GitHub/Gitee 仓库使用 `modpack/latest.json`。支持多个网盘：

```json
{
  "schema": 2,
  "product": "xingli_modpack",
  "enabled": true,
  "pack_id": "xingli-skyrim",
  "name": "星黎整合包",
  "version": "3.3.1",
  "title": "星黎整合包 3.3.1",
  "changelog": "当前稳定版",
  "download_pages": [
    {"name": "夸克网盘", "url": "https://pan.quark.cn/s/cb6b1774f50b", "code": "dbrf"},
    {"name": "百度网盘", "url": "https://pan.baidu.com/s/1Gbh37U81nsgzseZ0fbM6Mg", "code": "9se4"}
  ]
}
```

当远端版本高于本机版本时：

1. 主页显示橙色“有新版本”；
2. 启动后自动提示一次；
3. 用户选择网盘后，星黎复制对应提取码并打开网页；
4. 星黎助手不会自动下载、安装或覆盖整合包文件。
