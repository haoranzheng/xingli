# 星黎整合包更新提示

整合包内容更新与星黎助手自身更新是两套独立机制。

## 客户端本机版本

编辑 `modpack_release.json`：

```json
{
  "schema": 1,
  "pack_id": "xingli-skyrim",
  "name": "星黎整合包",
  "installed_version": "3.0.0"
}
```

整合包正式发布时，应把 `installed_version` 写成该整合包实际版本。
如果这里为空，星黎助手不会猜测版本；如果用户已经建立“整合包检查”基准，则会使用基准中的整合包版本作为后备。

## 远程最新版本

GitHub/Gitee 仓库使用：`modpack/latest.json`。

启用后的格式：

```json
{
  "schema": 1,
  "product": "xingli_modpack",
  "enabled": true,
  "pack_id": "xingli-skyrim",
  "name": "星黎整合包",
  "version": "3.1.0",
  "title": "3.1 内容更新",
  "published_at": "2026-09-08T17:00:00+08:00",
  "changelog": "新增内容……",
  "download_page": "https://你的网盘网页地址"
}
```

当远端 `version` 高于本机版本时：

1. 主页显示橙色“有新版本”；
2. 启动后自动提示一次；
3. 用户点击“前往网盘”后，才会调用默认浏览器打开 `download_page`；
4. 星黎助手不会自动下载、安装或覆盖整合包文件。
