# 星黎整合包检查

v2.0.0 首次加入整合包基线系统。

## 使用方式

1. 在你确认整合包运行正常、MOD 启停和顺序已经固定时，点击「建立当前基准」。
2. 填写整合包名称和版本。
3. 之后如果安装/删除 MOD、改变启停或顺序、修改插件顺序或 Profile INI，可点击「检查当前状态」。
4. 检查报告保存在 MO2 pluginDataPath 下的 `xingli_assistant/modpack/`。

## 当前记录范围

- 当前 Profile 的 `modlist.txt`
- `plugins.txt`
- `loadorder.txt`
- `Skyrim.ini`
- `SkyrimPrefs.ini`
- `SkyrimCustom.ini`（存在时）
- MO2 / 游戏 / Profile 基本标识

v2.0.0 不遍历整个 mods 目录，不哈希大型资源文件，也不会自动修复状态。
