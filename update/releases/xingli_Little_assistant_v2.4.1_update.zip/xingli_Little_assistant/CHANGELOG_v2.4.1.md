# v2.4.1：排序备份更新

- 暂时屏蔽单独 MOD 更新的入口和启动推送；代码保留，后续可恢复。
- 新增排序备份独立清单，通过 Gitee 国内主源及 GitHub Raw 备用源检查和下载。
- 左侧排序备份仅为 modlist.txt；右侧排序备份必须包含 plugins.txt、loadorder.txt、lockedorder.txt 三件套。
- 按 MO2 原生恢复规则命名，下载后以 YYYY_MM_DD_hh_mm_ss_Xingli_序号 保存到当前 Profile。
- 严禁覆盖现有 modlist.txt / plugins.txt / loadorder.txt / lockedorder.txt 与既有备份。
- 下载完成后需用户自行在 MO2 原生“还原”下拉框中选择新备份，不会自动改动排序。
- 按 Profile 记录已下载发布版本，重复启动不反复提示同一个更新。
